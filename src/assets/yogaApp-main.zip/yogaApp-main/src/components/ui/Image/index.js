import image from "./Image";
export default image;
