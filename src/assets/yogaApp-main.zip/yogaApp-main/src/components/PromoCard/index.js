import PromoCard from "./PromoCard";
export default PromoCard;
